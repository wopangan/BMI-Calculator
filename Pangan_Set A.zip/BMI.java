import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BMI extends JFrame
{
    JLabel heightL = new JLabel();
    JLabel feetL = new JLabel();
    JLabel inchesL = new JLabel();
    JLabel weightL = new JLabel();
    JLabel poundsL = new JLabel();
    JLabel bmiL = new JLabel();
        
    JTextField hFeet = new JTextField();
    JTextField hInches = new JTextField();
    JTextField wPounds = new JTextField();
    JTextField bmiField = new JTextField();
        
    JButton computeBMI = new JButton();
    JButton clearOption = new JButton();
    JButton exitOption = new JButton();
    
    private void exit(ActionEvent e)
    {
        JFrame w = new JFrame();
        JOptionPane.showMessageDialog(w,"Exitting Program");
        System.exit(0);
    }
    
    private void getBMI(ActionEvent e)
    {
        JFrame w = new JFrame();
        float feetVal = Float.parseFloat(hFeet.getText());
        float inchVal = Float.parseFloat(hInches.getText());
        float weightVal = Float.parseFloat(wPounds.getText());
        
        float feetFinalVal = feetVal * 12;
        float totalHeight = feetFinalVal + inchVal;
        float heightFinalVal = totalHeight * totalHeight;
        
        float bmiVal = weightVal / heightFinalVal;
        float bmiFinalVal = bmiVal * 703;

	bmiField.setText(""+String.format("%.2f",bmiFinalVal));

        //walang output sa bmi yun nalang kulang
        
    }
    
    private void clearNum(ActionEvent e)
    {
        hFeet.setText("");
        hInches.setText("");
        wPounds.setText("");
        bmiField.setText("");
    }
    
    public BMI()
    {
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridC = new GridBagConstraints();
        
        setTitle("BMI Calculator");
    
        //Height
        heightL.setText("Height: ");
        gridC.gridx = 0;
        gridC.gridy = 0;
        getContentPane().add(heightL,gridC);
        
        hFeet.setText("");
        hFeet.setColumns(5);
        gridC.gridx = 1;
        gridC.gridy = 0;
        getContentPane().add(hFeet, gridC);
        
        feetL.setText("feet");
        gridC.gridx = 2;
        gridC.gridy = 0;
        getContentPane().add(feetL, gridC);
        
        hInches.setText("");
        hInches.setColumns(5);
        gridC.gridx = 3;
        gridC.gridy = 0;
        getContentPane().add(hInches, gridC);
        
        inchesL.setText("inches");
        gridC.gridx = 4;
        gridC.gridy = 0;
        getContentPane().add(inchesL, gridC);
        
        //Weight
        weightL.setText("Weight: ");
        gridC.gridx = 0;
        gridC.gridy = 1;
        getContentPane().add(weightL, gridC);
        
        wPounds.setText("");
        wPounds.setColumns(5);
        gridC.gridx = 1;
        gridC.gridy = 1;
        getContentPane().add(wPounds, gridC);
        
        poundsL.setText("pounds");
        gridC.gridx = 2;
        gridC.gridy = 1;
        getContentPane().add(poundsL, gridC);
        
        //BMI
        bmiL.setText("BMI: ");
        gridC.gridx = 0;
        gridC.gridy = 2;
        getContentPane().add(bmiL, gridC);
        
        bmiField.setText("");
        bmiField.setColumns(5);
        gridC.gridx = 1;
        gridC.gridy = 2;
        getContentPane().add(bmiField, gridC);
        
        //Buttons
        computeBMI.setText("Compute BMI");
        gridC.gridx = 0;
        gridC.gridy = 3;
        getContentPane().add(computeBMI, gridC);
        
        clearOption.setText("Clear");
        gridC.gridx = 2;
        gridC.gridy = 3;
        getContentPane().add(clearOption, gridC);
        
        exitOption.setText("Exit");
        gridC.gridx = 3;
        gridC.gridy = 3;
        getContentPane().add(exitOption, gridC);
        
        //ActionListeners for the buttons
        computeBMI.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e)
	    { 
                getBMI(e);
            }
        });
        
        clearOption.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                clearNum(e);
            }
        });
        
        exitOption.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                exit(e);
            }
        });
        
        
        pack();
    }
    
    
    
    
    public static void main(String[] args)
    {
        new BMI().show();
    }
    
    
    
}
